package com.fixtrack.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [Product::class], version = 1, exportSchema = false)
abstract class FixTrackDatabase : RoomDatabase() {
    abstract fun productDao(): ProductDao

    companion object {
        @Volatile private var INSTANCE: FixTrackDatabase? = null

        fun get(context: Context): FixTrackDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext,
                FixTrackDatabase::class.java,
                "fixtrack.db"
            ).build().also { INSTANCE = it }
        }
    }
}
