# FixTrack (starter MVP)

**Track It. Maintain It. Save More.**

An offline-first native Android starter app using Kotlin, Jetpack Compose, Material 3, and Room. It currently supports adding and deleting product records, showing product count and total purchase value, and recording an optional warranty end date. Records are stored in a local Room database.

## Important scope note

This is the first working milestone, not the full feature set. Warranty alerts, scheduled reminders, repair history, backup/restore, dark-mode settings, and spending charts are planned next. The UI intentionally does not claim those features are implemented yet.

## Build with GitHub Actions (phone-friendly)

1. Create a new **public** GitHub repository named `FixTrack` (public repositories are easiest for free cloud builds; don't upload private receipts or personal data).
2. Upload the project files and folders to the repository root, preserving their directory structure. Include the hidden `.github/workflows/build-apk.yml` workflow.
3. Commit to the `main` branch.
4. Open the repository's **Actions** tab. Select **Build FixTrack APK**. The workflow should start automatically after the push; you can also select **Run workflow**.
5. Open the completed green workflow run. Under **Artifacts**, download `FixTrack-debug-apk`.
6. Extract the downloaded artifact ZIP on your Android phone. Tap `app-debug.apk` and allow installation from your browser/files app if Android asks.

GitHub may show different menu labels on mobile. No repository secrets, API keys, payment account, or cloud database are required.

## Build locally

Open this project in Android Studio on a computer with JDK 17 and Android SDK 35, then run `gradle assembleDebug` or use Android Studio's Build APK action. This repository intentionally uses the cloud workflow to build for a phone-only beginner.

## Technical versions

- Android Gradle Plugin: 8.7.3
- Gradle: 8.9 (provided by GitHub Actions)
- JDK: 17
- Kotlin: 2.0.21
- Compose BOM: 2024.12.01
- Room: 2.6.1
- Package: `com.fixtrack.app`

## Privacy and data

No account, internet permission, ads, billing, or subscription code is included. Product records stay in the app's local database. Uninstalling the app or clearing app data can remove records; export/restore is not implemented in this starter milestone yet.
