package com.fixtrack.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class Product(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val category: String,
    val brand: String,
    val purchasePricePaise: Long,
    val warrantyEndDate: String,
    val status: String = "Working",
    val createdAt: Long = System.currentTimeMillis()
)
